import prompt


def welcome_user():
    name0 = prompt.string('May I have your name? ')
    print(f'Hello, {name0}!')
